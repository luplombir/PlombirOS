// Plombir OS server: Express + WebSocket + SQLite
const express = require("express"), http = require("http"), path = require("path"), crypto = require("crypto");
const { WebSocketServer } = require("ws"), Database = require("better-sqlite3");

const db = new Database(process.env.DB_PATH || path.join(__dirname, "data.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT UNIQUE COLLATE NOCASE, salt TEXT, hash TEXT,
  role TEXT DEFAULT 'User', color TEXT, mute_until INTEGER DEFAULT 0, mute_reason TEXT DEFAULT '',
  ban_until INTEGER DEFAULT 0, ban_reason TEXT DEFAULT '', created INTEGER);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, uid INTEGER, created INTEGER);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY, name TEXT, color TEXT, sys INTEGER, text TEXT, ts INTEGER);
`);

const COLORS = ["#ffb4a2", "#b8c0ff", "#a8e6cf", "#ffd6a5", "#e0aaff"];
const now = () => Date.now();
const act = v => v === -1 || v > now();               // -1 = permanent
const staff = u => u.role === "Admin" || u.role === "Moderator";
const hash = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString("hex");
const byId = id => db.prepare("SELECT * FROM users WHERE id=?").get(id);
const pub = u => ({ id: u.id, name: u.name, role: u.role, color: u.color });
const until = v => (v === -1 ? "" : " until " + new Date(v).toLocaleString());

const app = express(), server = http.createServer(app);
app.set("trust proxy", 1);
app.use(express.json({ limit: "2kb" }));
app.use(express.static(path.join(__dirname, "public")));

const cookie = (req, n) => ((req.headers.cookie || "").match(new RegExp("(?:^|; )" + n + "=([^;]*)")) || [])[1];
const setCookie = (res, v, age) => res.setHeader("Set-Cookie",
  `sid=${v}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${age}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
const userOf = req => {
  const t = cookie(req, "sid"); if (!t) return null;
  return db.prepare("SELECT u.* FROM sessions s JOIN users u ON u.id=s.uid WHERE s.token=?").get(t) || null;
};
const startSession = (res, id) => {
  const t = crypto.randomBytes(32).toString("hex");
  db.prepare("DELETE FROM sessions WHERE created<?").run(now() - 30 * 864e5);
  db.prepare("INSERT INTO sessions VALUES(?,?,?)").run(t, id, now());
  setCookie(res, t, 30 * 86400);
};
const tries = new Map();
const limited = ip => { const r = (tries.get(ip) || []).filter(x => now() - x < 6e4); r.push(now()); tries.set(ip, r); return r.length > 10; };

app.post("/api/signup", (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: "Too many tries. Wait a minute." });
  const { name, pw } = req.body || {};
  if (!/^\w{3,16}$/.test(name || "")) return res.status(400).json({ error: "Use 3–16 letters, numbers or underscores." });
  if (typeof pw !== "string" || pw.length < 6 || pw.length > 100) return res.status(400).json({ error: "Password needs 6–100 characters." });
  if (db.prepare("SELECT 1 FROM users WHERE name=?").get(name)) return res.status(400).json({ error: "That username is taken." });
  const n = db.prepare("SELECT COUNT(*) c FROM users").get().c, salt = crypto.randomBytes(16).toString("hex");
  const id = db.prepare("INSERT INTO users(name,salt,hash,role,color,created) VALUES(?,?,?,?,?,?)")
    .run(name, salt, hash(pw, salt), n ? "User" : "Admin", COLORS[n % COLORS.length], now()).lastInsertRowid;
  startSession(res, id); res.json({ ok: 1 });
});
app.post("/api/login", (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: "Too many tries. Wait a minute." });
  const { name, pw } = req.body || {}, u = db.prepare("SELECT * FROM users WHERE name=?").get(String(name || ""));
  if (!u || !crypto.timingSafeEqual(Buffer.from(hash(String(pw || ""), u.salt)), Buffer.from(u.hash)))
    return res.status(401).json({ error: "Wrong username or password." });
  if (act(u.ban_until)) return res.status(403).json({ error: `This account is banned${until(u.ban_until)}. Reason: ${u.ban_reason}` });
  startSession(res, u.id); res.json({ ok: 1 });
});
app.get("/api/me", (req, res) => {
  const u = userOf(req);
  if (!u || act(u.ban_until)) return res.status(401).json({});
  res.json(pub(u));
});
app.post("/api/logout", (req, res) => {
  const t = cookie(req, "sid"); if (t) db.prepare("DELETE FROM sessions WHERE token=?").run(t);
  setCookie(res, "", 0); res.json({ ok: 1 });
});

// ---- live part ----
const wss = new WebSocketServer({ server, path: "/ws", maxPayload: 4096 });
const clients = new Map(); // ws -> user id
const send = (ws, o) => ws.readyState === 1 && ws.send(JSON.stringify(o));
const all = o => wss.clients.forEach(ws => send(ws, o));

function people() {
  const on = new Set(clients.values());
  all({ t: "people", list: db.prepare("SELECT id,name,role,color,ban_until FROM users").all()
    .filter(u => !act(u.ban_until)).map(u => ({ name: u.name, role: u.role, color: u.color, online: on.has(u.id) })) });
}
function say(text, u) {
  const m = { name: u ? u.name : "", color: u ? u.color : "", sys: u ? 0 : 1, text, ts: now() };
  m.id = db.prepare("INSERT INTO msgs(name,color,sys,text,ts) VALUES(?,?,?,?,?)").run(m.name, m.color, m.sys, m.text, m.ts).lastInsertRowid;
  all({ t: "msg", m });
}
const DUR = { "10m": 6e5, "1h": 36e5, "1d": 864e5, "7d": 6048e5, perm: -1 };

function moderate(ws, u, d) {
  const err = m => send(ws, { t: "err", m }), a = d.action, t = byId(+d.id);
  const why = String(d.reason || "").trim().slice(0, 80);
  if (!t || t.id === u.id) return err("Pick someone else.");
  if (a === "role") {
    if (u.role !== "Admin") return err("Only admins can change roles.");
    if (!["User", "Moderator", "Admin"].includes(d.role)) return;
    db.prepare("UPDATE users SET role=? WHERE id=?").run(d.role, t.id);
    say(`${t.name} is now ${d.role}. Set by ${u.name}.`);
  } else if (!(u.role === "Admin" || (u.role === "Moderator" && t.role === "User"))) {
    return err("You can’t do that to this person.");
  } else if (a === "unmute" || a === "unban") {
    const c = a === "unmute" ? "mute" : "ban";
    db.prepare(`UPDATE users SET ${c}_until=0 WHERE id=?`).run(t.id);
    say(`${t.name} was ${a === "unmute" ? "unmuted" : "unbanned"} by ${u.name}.`);
  } else if (a === "mute" || a === "ban") {
    const ms = DUR[d.dur];
    if (ms === undefined || !why) return err("Pick a duration and give a reason.");
    db.prepare(`UPDATE users SET ${a}_until=?, ${a}_reason=? WHERE id=?`).run(ms === -1 ? -1 : now() + ms, why, t.id);
    say(`${t.name} was ${a === "ban" ? "banned" : "muted"} ${ms === -1 ? "permanently" : "for " + d.dur} by ${u.name}. Reason: ${why}`);
    if (a === "ban") {
      db.prepare("DELETE FROM sessions WHERE uid=?").run(t.id);
      clients.forEach((id, w) => { if (id === t.id) w.close(4001); });
    }
  } else return;
  people(); all({ t: "refresh" });
}

wss.on("connection", (ws, req) => {
  const o = req.headers.origin;
  if (o && new URL(o).host !== req.headers.host) return ws.close(4003);   // block cross-site connections
  const u0 = userOf(req);
  if (!u0 || act(u0.ban_until)) return ws.close(4001);
  clients.set(ws, u0.id);
  send(ws, { t: "hello", me: pub(u0),
    history: db.prepare("SELECT * FROM (SELECT * FROM msgs ORDER BY id DESC LIMIT 100) ORDER BY id").all() });
  people();
  let last = 0;
  ws.on("message", raw => {
    let d; try { d = JSON.parse(raw); } catch { return; }
    const u = byId(clients.get(ws));
    if (!u || act(u.ban_until)) return ws.close(4001);
    if (d.t === "chat") {
      const m = String(d.m || "").trim().slice(0, 500);
      if (!m || now() - last < 700) return;
      if (act(u.mute_until)) return send(ws, { t: "err", m: `You are muted${until(u.mute_until)}. Reason: ${u.mute_reason}` });
      last = now(); say(m, u);
    } else if (d.t === "users" && staff(u)) {
      send(ws, { t: "users", list: db.prepare("SELECT id,name,role,mute_until,ban_until FROM users").all() });
    } else if (d.t === "mod" && staff(u)) moderate(ws, u, d);
  });
  ws.on("close", () => { clients.delete(ws); people(); });
});

server.listen(process.env.PORT || 3000, () => console.log("Plombir OS is running on port " + (process.env.PORT || 3000)));
